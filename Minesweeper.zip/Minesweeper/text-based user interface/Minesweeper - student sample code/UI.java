import java.util.Scanner;
/**
 * This class provides a text based user interface for the player to interact with the game
 * @author Lauren Scott
 * @version student sample code
 */
public class UI {
    private Minesweeper thegame;//this is the game model
    private String menuChoice;//this is the users choice from the menu
    private Scanner reader;//this scanner is used to read the terminal
    /**
     * Constructor for the class UI
     */
    public UI() {
        thegame = new Minesweeper();
        reader = new Scanner(System.in);
        menuChoice="";
        while(!menuChoice.equalsIgnoreCase("Q")&& thegame.checkWin().equals("continue")) {
            displayGame();
            menu();
            menuChoice = getChoice();

        }
        if (thegame.checkWin().equals("won") ){
            winningAnnouncement();
        } else if (thegame.checkWin().equals("lives") ){
            livesAnnouncement();
        }
    }

    /**
     * Method that outputs an announcement when the user has won the game
     */
    public void winningAnnouncement() {
        System.out.println("\nCongratulations, you solved the level");
    }
    /**
     * Method that outputs an announcement when the user has lost due to lack of lives
     */
    public void livesAnnouncement() {
        System.out.println("\nYou have ran out of lives, the game is over");
    }
    /**
     * Method that displays the game for the user to play
     */
    public void displayGame() {
        //boardmoves = thegame.getMoves();
        
        System.out.print("\n\nCol    ");
        for (int r = 0; r < thegame.getGameSize(); r++) {
            System.out.print(r + " ");
        }
        for (int i = 0; i < thegame.getGameSize(); i++) {
            System.out.print("\nRow  " + i);
            for (int c = 0; c < thegame.getGameSize() ; c++) {
                System.out.print(" "+thegame.getCellState(i,c));
            }
        }
        
    }

    /**
     * Method that displays the menu to the user
     */
    public void menu() {

        System.out.println("\nPlease select an option: \n"
            + "[M] Flag a mine\n"
            + "[G] Guess a square\n"
            + "[S] save game\n"
            + "[L] load saved game\n"
            + "[U] undo move\n"
            + "[C] clear game\n"
            + "[Q] quit game\n");

    }

    /**
     * Method that gets the user's choice from the menu and conducts the activities
     * accordingly
     * @return the choice the user has selected
     * 
     */
    public String getChoice() {
        String choice = reader.next();
        if (choice.equalsIgnoreCase("M") || choice.equalsIgnoreCase("G")) {
            System.out.print("Which row is the cell you wish to flag?  ");
            String row = reader.next();
            System.out.print("Which colum is the cell you wish to flag?  ");
            String col = reader.next();
            System.out.print(thegame.makeMove(row, col, choice));
            

        } else if (choice.equalsIgnoreCase("S")) {
            saveGame();
        } else if (choice.equalsIgnoreCase("U")) {
            undoMove();
        } else if (choice.equalsIgnoreCase("L")) {
            loadGame();
        } else if (choice.equalsIgnoreCase("C")) {
            clearGame();
        } else if (choice.equalsIgnoreCase("Q")) {
            System.exit(0);
        }
        return choice;
    }

    /**
     * saveGame 
     * To be implemented by student - this method should save the current state of the game, along with the corresponding computer move
     */
    public void saveGame() {
        System.out.println("Code not yet implemented");
    }

    /**
     * undoMove 
     * To be implemented by student - this method should undo the previous move made in the game, along with the corresponding computer move
     */
    public void undoMove() {
        System.out.println("Code not yet implemented");
    }

    /**
     * loadGame
     * To be implemented by student - this method should load a previous saved game
     */
    public void loadGame() {
        System.out.println("Code not yet implemented");
    }

    /**
     * clearGame
     * To be implemented by student - this method should clear the game board and any record of moves, to reset the game
     */
    public void clearGame() {
        System.out.println("Code not yet implemented");
    }

    /**
     * The main method within the Java application. 
     * It's the core method of the program and calls all others.
     */
    public static void main(String args[]) {
       UI ui= new UI();
       ui.getChoice();
        
    }
}//end of class UI