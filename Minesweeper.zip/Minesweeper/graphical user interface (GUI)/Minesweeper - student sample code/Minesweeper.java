import java.io.*;
import java.util.Scanner;
import java.util.Stack;
/**
 * This is the class Sudoku and it handles the functionality of the main game.
 * @author Lauren Scott
 * @version Student Sample Code
 */
public class Minesweeper {
    private String[][] gameBoard;
    private Slot[][] playerBoard;
    private Scanner reader;
    private int gameSize;
    private int lives = 3;
    private Stack<int[]> moveHistory = new Stack<>();

    public Minesweeper() {
        try {
            reader = new Scanner(new File("Levels/em1.txt"));
        } catch (FileNotFoundException e) {
            System.err.println("File not found: " + e.getMessage());
        }
        gameSize = calculateGameSize();
        gameBoard = new String[gameSize][gameSize];
        playerBoard = new Slot[gameSize][gameSize];
        readLevelFile();
    }
   /**
     * This method gets the entire set of moves in the game
     * @return the set of moves
     */
    public Slot[][] getMoves() {
        return playerBoard;
    }
 /**
     * This method gets an individual cell's state
     * @param row - the row of the move
     * @param col - the column of the move
     * @return The state of that cell
     */
    public String getIndividualMove(int row, int col) {
        return playerBoard[row][col].getState();
    }
 /**
     * This method reads the game size from the file 
     * @return the size of the puzzle
     */
    private int calculateGameSize() {
        return Integer.parseInt(reader.next());
    }
 /**
     * This method provides access to the gameSize from other classes
     * @return the size of the puzzle
     */
    public int getGameSize() {
        return gameSize;
    }
  /**
     * This method reads the level file to populate the game
     * @return The moves stored in the file
     */
    private void readLevelFile() {
        while (reader.hasNext()) {
            int row = Integer.parseInt(reader.next());
            int col = Integer.parseInt(reader.next());
            String move = reader.next();
            gameBoard[row][col] = move;
            playerBoard[row][col] = new Slot(row, col, "?");
        }
    }
  /**
     * This method checks whether the gane has been won
     * @return whether the game has been won
     */ 
    public String checkWin() {
        if (lives != 0) {
            for (int i = 0; i < gameSize; i++) {
                for (int c = 0; c < gameSize; c++) {
                    if (!playerBoard[i][c].getState().equals(gameBoard[i][c])) {
                        return "continue";
                    }
                }
            }
            return "won";
        } else {
            return "lives";
        }
    }
   /**
     * This method allows a user to make a move in the game
     * @param row - the row of the move
     * @param col - the column of the move
     * @param number - the number they are wishing to enter in the cell
     * @return whether the move was valid
     */
    public String makeMove(int row, int col, String guess) {
        moveHistory.push(new int[]{row, col, lives});
        if (guess.equals("M") && gameBoard[row][col].equals("M")) {
            playerBoard[row][col].setState("M");
        } else if (guess.equals("G")) {
            if (gameBoard[row][col].equals("M")) {
                lives--;
                playerBoard[row][col].setState("M");
                return "You have lost one life. \nNew life total: " + lives;
            } else if (gameBoard[row][col].equals("-")) {
                playerBoard[row][col].setState("-");
            } else {
                playerBoard[row][col].setState(gameBoard[row][col]);
            }
            return "You have survived this time";
        } else {
            return "Unsuccessful - this was not a mine";
        }
        return "You have successfully found a mine";
    }
   /**
     * This method gets the current state of an individual cell
     * @param row - the row of the cell
     * @param col - the column of the cell
     * @return the state of the cell
     */
    public String getCellState(int row, int col) {
        return playerBoard[row][col].getState();
    }

    public int getLives() {
        return lives;
    }

    public void saveGame(String fileName) throws IOException {
        try (PrintWriter writer = new PrintWriter(new FileWriter(fileName))) {
            writer.println(gameSize);
            writer.println(lives);
            for (int i = 0; i < gameSize; i++) {
                for (int j = 0; j < gameSize; j++) {
                    writer.println(i + " " + j + " " + gameBoard[i][j]);
                    writer.println(i + " " + j + " " + playerBoard[i][j].getState());
                }
            }
        }
    }

    public void loadGame(String fileName) throws IOException {
        try (BufferedReader reader = new BufferedReader(new FileReader(fileName))) {
            gameSize = Integer.parseInt(reader.readLine());
            lives = Integer.parseInt(reader.readLine());
            gameBoard = new String[gameSize][gameSize];
            playerBoard = new Slot[gameSize][gameSize];
            for (int i = 0; i < gameSize; i++) {
                for (int j = 0; j < gameSize; j++) {
                    String[] gameBoardData = reader.readLine().split(" ");
                    gameBoard[Integer.parseInt(gameBoardData[0])][Integer.parseInt(gameBoardData[1])] = gameBoardData[2];
                    String[] playerBoardData = reader.readLine().split(" ");
                    playerBoard[Integer.parseInt(playerBoardData[0])][Integer.parseInt(playerBoardData[1])] = new Slot(
                            Integer.parseInt(playerBoardData[0]),
                            Integer.parseInt(playerBoardData[1]),
                            playerBoardData[2]);
                }
            }
        }
    }

    public void undoMove() {
        if (!moveHistory.isEmpty()) {
            int[] lastMove = moveHistory.pop();
            int row = lastMove[0];
            int col = lastMove[1];
            lives = lastMove[2];
            playerBoard[row][col].setState("?");
        }
    }

    public void clearBoard() {
        for (int i = 0; i < gameSize; i++) {
            for (int j = 0; j < gameSize; j++) {
                playerBoard[i][j].setState("?");
            }
        }
        lives = 3;
        moveHistory.clear();
    }
}
