import javax.swing.*;
import javax.swing.border.Border;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.util.Observable;
import java.util.Observer;
/**
 * This class provides a text based user interface for the player to interact with the game
 * @author Lauren Scott
 * @version student sample code
 */

public class UI extends JFrame implements Observer {
    private Minesweeper game;
    private JButton[][] buttons;
    private JPanel boardPanel;
    private JLabel livesLabel;
    private JButton toggleButton;
    private boolean flagMode = true;
/**
     * Constructor for the class UI
     */
    public UI() {
        game = new Minesweeper();
        buttons = new JButton[game.getGameSize()][game.getGameSize()];
        setTitle("Minesweeper Assessment");
        setSize(430, 500);
        setFont(new Font("Arial", Font.BOLD, 14));
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        Border compoundBorder = BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(Color.cyan),
                new RoundedBorder(13)
        );

        boardPanel = new JPanel();
        boardPanel.setLayout(new GridLayout(game.getGameSize(), game.getGameSize()));

        for (int i = 0; i < game.getGameSize(); i++) {
            for (int j = 0; j < game.getGameSize(); j++) {
                buttons[i][j] = new JButton("?");
                buttons[i][j].addActionListener(new ButtonListener(i, j));
                boardPanel.add(buttons[i][j]);
                game.getMoves()[i][j].addObserver(this);
            }
        }

        JPanel sidePanel = new JPanel();
        sidePanel.setBackground(Color.CYAN);
        sidePanel.setBorder(BorderFactory.createEmptyBorder(7, 7, 7, 7));
        sidePanel.setLayout(new GridLayout(7, 1, 7, 7));

        livesLabel = new JLabel("Lives: 3");
        livesLabel.setFont(new Font("Arial", Font.BOLD, 14));
        sidePanel.add(livesLabel);

        JLabel modeLabel = new JLabel("Mode: Flag");
        modeLabel.setFont(new Font("Arial", Font.BOLD, 14));
        sidePanel.add(modeLabel);

        toggleButton = new JButton("Toggle");
        toggleButton.setFont(new Font("Arial", Font.BOLD, 14));
        toggleButton.addActionListener(e -> {
            flagMode = !flagMode;
            modeLabel.setText("Mode: " + (flagMode ? "Flag" : "Guess"));
        });
        toggleButton.setBorder(compoundBorder);
        sidePanel.add(toggleButton);

        JButton saveButton = new JButton("Save");
        saveButton.setFont(new Font("Arial", Font.BOLD, 14));
        saveButton.setBorder(compoundBorder);
        saveButton.addActionListener(e -> {
            try {
                game.saveGame("saved_game.txt");
                JOptionPane.showMessageDialog(UI.this, "Game saved successfully.");
            } catch (IOException ex) {
                JOptionPane.showMessageDialog(UI.this, "Error saving game: " + ex.getMessage());
            }
        });
        sidePanel.add(saveButton);

        JButton undoButton = new JButton("Undo");
        undoButton.setFont(new Font("Arial", Font.BOLD, 14));
        undoButton.setBorder(compoundBorder);
        undoButton.addActionListener(e -> {
            game.undoMove();
            refreshBoard();
        });
        sidePanel.add(undoButton);

        JButton clearButton = new JButton("Clear");
        clearButton.setFont(new Font("Arial", Font.BOLD, 14));
        clearButton.setBorder(compoundBorder);
        clearButton.addActionListener(e -> {
            game.clearBoard();
            refreshBoard();
            JOptionPane.showMessageDialog(UI.this, "Board cleared.");
        });
        sidePanel.add(clearButton);

        JButton loadButton = new JButton("Load");
        loadButton.setFont(new Font("Arial", Font.BOLD, 14));
        loadButton.setBorder(compoundBorder);
        loadButton.addActionListener(e -> {
            try {
                game.loadGame("saved_game.txt");
                refreshBoard();
                JOptionPane.showMessageDialog(UI.this, "Game loaded successfully.");
            } catch (IOException ex) {
                JOptionPane.showMessageDialog(UI.this, "Error loading game: " + ex.getMessage());
            }
        });
        sidePanel.add(loadButton);

        add(boardPanel, BorderLayout.CENTER);
        add(sidePanel, BorderLayout.EAST);

        setVisible(true);
    }

    private void refreshBoard() {
        for (int i = 0; i < game.getGameSize(); i++) {
            for (int j = 0; j < game.getGameSize(); j++) {
                updateButtonState(i, j);
            }
        }
        livesLabel.setText("Lives: " + game.getLives());
    }

    private void updateButtonState(int row, int col) {
        String state = game.getCellState(row, col);
        JButton button = buttons[row][col];

        if (state.equals("M")) {
            button.setText("M");
            button.setBackground(Color.BLUE); // Change color for flagged cells
        } else if (state.equals("?")) {
            button.setText("?");
            button.setBackground(UIManager.getColor("Button.background")); // Reset color for unrevealed cells
        } else if (state.equals("-")) {
            button.setText("");
            button.setBackground(Color.LIGHT_GRAY); // Change color for revealed empty cells
        } else if (state.equals("G")) {
                button.setText("");
                button.setBackground(Color.pink);
        } else {
            button.setText(state);
            button.setBackground(Color.YELLOW); // Change color for revealed cells with content
        }
    }

    private class ButtonListener implements ActionListener {
        private int row, col;

        public ButtonListener(int row, int col) {
            this.row = row;
            this.col = col;
        }

        @Override
        public void actionPerformed(ActionEvent e) {
            if (flagMode) {
                String moveResult = game.makeMove(row, col, "M");
                JOptionPane.showMessageDialog(UI.this, moveResult);
            } else {
                String moveResult = game.makeMove(row, col, "G");
                JOptionPane.showMessageDialog(UI.this, moveResult);
            }
          /**  if (flagMode) {
                String moveResult = game.makeMove(row, col, "M");
                JOptionPane.showMessageDialog(UI.this, moveResult);
            } else {
                String moveResult = game.makeMove(row, col, "G");
                JOptionPane.showMessageDialog(UI.this, moveResult);
            }
            **/
                  
            if (game.checkWin().equals("won")) {
                JOptionPane.showMessageDialog(UI.this, "Congratulations, you solved the level!");
            } else if (game.checkWin().equals("lives")) {
                JOptionPane.showMessageDialog(UI.this, "You have run out of lives, the game is over.");
            }
            refreshBoard();
        }
    }

    @Override
    public void update(Observable o, Object arg) {
        Slot slot = (Slot) o;
        updateButtonState(slot.getRow(), slot.getCol());
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(UI::new);
    }

    private static class RoundedBorder implements Border {
        private int radius;

        RoundedBorder(int radius) {
            this.radius = radius;
        }

        public Insets getBorderInsets(Component c) {
            return new Insets(this.radius + 2, this.radius + 2, this.radius + 3, this.radius);
        }

        public boolean isBorderOpaque() {
            return true;
        }

        public void paintBorder(Component c, Graphics g, int x, int y, int width, int height) {
            g.drawRoundRect(x, y, width - 2, height - 2, radius, radius);
        }
    }
}
